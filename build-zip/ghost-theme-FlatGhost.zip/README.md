# FlatGhost
Just a flat style theme for Ghost.
